<template>
  <div>
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'IndexChatFlow'
}
</script>

<style lang="scss" scoped>
</style>
